from pythonfofa.client import Client

